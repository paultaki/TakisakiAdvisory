
document.getElementById('mobile-toggle').addEventListener('click', function () {
  document.getElementById('navbar').querySelector('ul').classList.toggle('show');
});
